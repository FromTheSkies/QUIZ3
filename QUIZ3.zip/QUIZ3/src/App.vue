<template>
  <div class="todo-app">
    <h1>Task List</h1>

    <!-- Input for task title and priority -->
    <input v-model="newTaskTitle" placeholder="Enter task title" />
    <select v-model="newTaskPriority">
      <option value="low">Low</option>
      <option value="medium">Medium</option>
      <option value="high">High</option>
    </select>
    <button @click="addTask">Add Task</button>

    <!-- Display the list of tasks if there are any -->
    <div v-if="tasks.length">
      <h2>Pending Tasks: {{ pendingTasks }}</h2>

      <!-- Transition for adding/removing tasks -->
      <transition-group name="task" tag="div">
        <div
          v-for="task in tasks"
          :key="task.id"
          :class="['task', task.priority, { completed: task.completed }]"
        >
          <!-- Individual task animation (fade in/out) -->
          <transition name="fade">
            <p @click="toggleTaskCompletion(task)">{{ task.title }}</p>
          </transition>

          <button @click="deleteTask(task.id)">Delete</button>
        </div>
      </transition-group>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      newTaskTitle: '',
      newTaskPriority: 'low',
      tasks: [],
    };
  },
  computed: {
    // Computed property to count pending tasks
    pendingTasks() {
      return this.tasks.filter((task) => !task.completed).length;
    },
  },
  methods: {
    // Add a new task to the list
    addTask() {
      if (this.newTaskTitle.trim()) {
        const newTask = {
          id: Date.now(),
          title: this.newTaskTitle.trim(),
          priority: this.newTaskPriority,
          completed: false,
        };
        this.tasks.push(newTask);
        this.newTaskTitle = '';
        // Use nextTick to scroll to the newly added task
        this.$nextTick(() => {
          const lastTask = this.$el.querySelector('.task:last-child');
          lastTask?.scrollIntoView({ behavior: 'smooth' });
        });
      }
    },
    // Delete a task by its ID
    deleteTask(taskId) {
      this.tasks = this.tasks.filter((task) => task.id !== taskId);
    },
    // Toggle the completion status of a task
    toggleTaskCompletion(task) {
      task.completed = !task.completed;
    },
  },
  watch: {
    // Watch for changes in tasks and log a message
    tasks(newTasks) {
      if (newTasks.length > 0) {
        console.log('Task list updated.');
      }
    },
  },
};
</script>

<style scoped>
.todo-app {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  text-align: center;
}

input {
  padding: 5px;
  margin-right: 10px;
}

button {
  padding: 5px 10px;
  cursor: pointer;
}

select {
  padding: 5px;
}

.task {
  display: flex;
  justify-content: space-between;
  padding: 10px;
  margin: 5px 0;
  border: 1px solid #ddd;
  border-radius: 5px;
}

.task.low {
  background-color: lightyellow;
}

.task.medium {
  background-color: lightblue;
}

.task.high {
  background-color: lightcoral;
}

.task.completed p {
  text-decoration: line-through;
}

.task p {
  cursor: pointer;
}

.task button {
  background-color: red;
  color: white;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
}

.task-enter-active,
.task-leave-active {
  transition: opacity 0.5s;
}

.task-enter, .task-leave-to {
  opacity: 0;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter, .fade-leave-to {
  opacity: 0;
}
</style>
